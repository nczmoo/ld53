SUMMARY

TODO
    Create persons with race, sexuality, gender, and political affiliation.
    Each person has opinions. Some of these opinions are known.
    

    Deliver the sermon.
        Pick a topic. (see opinions)
        Pick a polarity. (see opnions)
        Do this in time.
    
    x People react to your sermon and leave or bring more accordingly.
    You can, personally, ask certain people to come back for your next sermon.
    x create a log to narrate player's actions

    x put negatives adn positives to show where everyone is currently at
    x don't put previously chosen topics as next options
    x have more natural identities as topics
    x parishioners in the front have more violent responses than those in the back
    x have players who trust you sit closer
    x show previous responses when you click on stuff you've already clicked on
    x add more names
    refactor
    x show what people believe in after you've talked about a topic
    the more sermons they've attended, the more they trust you
    
QUESTIONS
    Should demographic info be clear?
        idk what this means
    How can I create an incentive for players to want to invest into topics?

    How can I create more player agency for people to manipulate their audience to THEIR beliefs?

DESIGN
    sermon delivery
        Demographics
            Gender
            Race
            Sexuality
            Political Affiliation

        Subjects
            Politics
                ? - Abortion, Government Regulation, Taxes
                Politicians
    You have <x> number of talking points.
    Each talking point, you can pick between three topics/subjects.
    Then you must pick negative or positive. If you don't choose in the time, everyone gets bored. If you get to N boredom, everyone leaves.   
    When you hover over the negative/positive or the topics, it shows you the established opinions of everyone in the audience.


    IDEAS REJECTED
        Drug delivery
        Package delivery
        Drone delivery 
        Drone delivery of bombs into the middle east
        Delivering a sermon
        hacker delivery
        term paper delivery
        shooting a basketball into a hoop
        delivery of death
        nuclear delivery'
        "Courier Chaos": A real-time strategy game where players manage a team of couriers, assigning deliveries, optimizing routes, and dealing with unexpected challenges along the way.
        "Delivery Duck": A puzzle game where players control a duck, delivering messages and packages to other ducks while avoiding predators and obstacles.
        Freestyle Rhythm Game - write a freestyle rap and then you basically have to do a rhythm game where each rhythme you have to connect with two buttons on beat.
        packet delivery    

MAYBE
    You can get to know people before the sermon.
    when a person has an emotional response, a person seated next to them having a similar response amplifies it.    
    create a second set of green / red for polarity section so players can see where they're at
    maybe as you're talking positively and negatively about these topics, you inspire your parish to do actual events outside of church.
