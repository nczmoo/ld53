class Loop{

    looping(){

    }

}